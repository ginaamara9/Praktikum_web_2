<?php
include_once 'templates/header.php';
include_once 'templates/topbar.php';
include_once 'templates/sidebar.php';
?>
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Silahkan isi form pendaftaran.</h1>
                        
                    </div>
                </main>
               
<?php
include_once 'templates/footer.php';
?>